import cookie from 'cookie'
import { API_URL } from '@/config/index'
import axios from 'axios'


export default async (req, res) => {
    if (req.method === 'POST') {
        console.log("innnnn");

        // const universities = await fetch(`${API_URL}/Universities?_limit=100`)
        // console.log(universities.json());
    }
}