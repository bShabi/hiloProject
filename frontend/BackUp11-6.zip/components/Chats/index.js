


export default function Chats() {
    return (
        <div>

        </div>
    )
}
