import Layout from "../../components/Layout";

export default function LifeandHacksPage() {
    return (
        <Layout>
            <h1>Life Hacks & Tips</h1>
        </Layout>
    )
}
