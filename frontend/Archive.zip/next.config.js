module.exports = {
    future: {
        webpack5: true,
    },
    images: {
        domains: ['res.cloudinary.com']
    }
}